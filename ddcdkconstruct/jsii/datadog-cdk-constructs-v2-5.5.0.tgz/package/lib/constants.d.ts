import * as lambda from "aws-cdk-lib/aws-lambda";
import { DatadogAppSecMode } from "./interfaces";
export declare const LAYER_PREFIX = "DatadogLayer";
export declare const EXTENSION_LAYER_PREFIX = "DatadogExtension";
export declare const DD_ACCOUNT_ID = "464622532012";
export declare const DD_GOV_ACCOUNT_ID = "002406178527";
export declare const DD_HANDLER_ENV_VAR = "DD_LAMBDA_HANDLER";
export declare const AWS_LAMBDA_EXEC_WRAPPER_ENV_VAR = "AWS_LAMBDA_EXEC_WRAPPER";
export declare const AWS_LAMBDA_EXEC_WRAPPER = "/opt/datadog_wrapper";
export declare const PYTHON_HANDLER = "datadog_lambda.handler.handler";
export declare const JS_HANDLER_WITH_LAYERS = "/opt/nodejs/node_modules/datadog-lambda-js/handler.handler";
export declare const JS_HANDLER = "node_modules/datadog-lambda-js/dist/handler.handler";
export declare const SUBSCRIPTION_FILTER_PREFIX = "DatadogSubscriptionFilter";
export declare enum RuntimeType {
    DOTNET = 0,
    NODE = 1,
    PYTHON = 2,
    JAVA = 3,
    RUBY = 4,
    CUSTOM = 5,
    UNSUPPORTED = 6
}
export declare const DatadogLambdaDefaultProps: {
    addLayers: boolean;
    enableDatadogTracing: boolean;
    datadogAppSecMode: DatadogAppSecMode;
    enableMergeXrayTraces: boolean;
    injectLogContext: boolean;
    enableDatadogLogs: boolean;
    captureLambdaPayload: boolean;
    captureCloudServicePayload: boolean;
    sourceCodeIntegration: boolean;
    redirectHandler: boolean;
    grantSecretReadAccess: boolean;
};
/**
 * For backward compatibility. It's recommended to use DatadogLambdaDefaultProps for
 * users who want to add Datadog monitoring for Lambda functions.
 */
export declare const DatadogDefaultProps: {
    addLayers: boolean;
    enableDatadogTracing: boolean;
    datadogAppSecMode: DatadogAppSecMode;
    enableMergeXrayTraces: boolean;
    injectLogContext: boolean;
    enableDatadogLogs: boolean;
    captureLambdaPayload: boolean;
    captureCloudServicePayload: boolean;
    sourceCodeIntegration: boolean;
    redirectHandler: boolean;
    grantSecretReadAccess: boolean;
};
export declare enum TagKeys {
    CDK = "dd_cdk_construct",
    ENV = "env",
    SERVICE = "service",
    VERSION = "version",
    DD_TRACE_ENABLED = "DD_TRACE_ENABLED"
}
export declare const runtimeLookup: {
    [key: string]: RuntimeType;
};
export declare function getRuntimeType(runtime: lambda.Runtime): RuntimeType | undefined;
export declare const runtimeToLayerName: {
    [key: string]: {
        x86_64: string;
        arm64: string;
    };
};
export declare const govCloudRegions: ReadonlyArray<string>;
/**
 * Valid Datadog site URLs
 */
export declare const siteList: string[];
export declare const invalidSiteError: string;
/**
 * Lambda functions with less memory than this (in MB) are considered low-memory. The Datadog
 * Lambda Extension and tracer add memory overhead that can cause out-of-memory errors and timeouts.
 */
export declare const LOW_MEMORY_THRESHOLD_MB = 256;
/**
 * Reason code recorded when a Lambda function is below `LOW_MEMORY_THRESHOLD_MB`.
 */
export declare const LOW_MEMORY_REASON = "lambda_low_memory";
/**
 * Memory size (in MB) that AWS Lambda applies when `MemorySize` is not set.
 */
export declare const DEFAULT_LAMBDA_MEMORY_MB = 128;
export declare const LowMemoryWarningId = "datadog-cdk-constructs-v2:lambdaLowMemory";
