import { LambdaFunction } from "./interfaces";
export declare function setTrackedEnv(lam: LambdaFunction, key: string, value: string): void;
export declare function setTrackedPropTags(lam: LambdaFunction, value: string): void;
export declare function mergeTrackedGitTags(lam: LambdaFunction, value: string): void;
export declare function hasTrackedEnv(lam: LambdaFunction, key: string): boolean;
