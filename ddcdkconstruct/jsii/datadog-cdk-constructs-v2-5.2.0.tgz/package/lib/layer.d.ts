import { Construct } from "constructs";
import { LambdaFunction } from "./interfaces";
export declare function applyLayers(scope: Construct, region: string, lam: LambdaFunction, pythonLayerVersion?: number, pythonLayerArn?: string, nodeLayerVersion?: number, nodeLayerArn?: string, javaLayerVersion?: number, javaLayerArn?: string, dotnetLayerVersion?: number, dotnetLayerArn?: string, rubyLayerVersion?: number, rubyLayerArn?: string, useLayersFromAccount?: string): string[];
export declare function applyExtensionLayer(scope: Construct, region: string, lam: LambdaFunction, extensionLayerVersion?: number, extensionLayerArn?: string, useLayersFromAccount?: string): string[];
export declare function getLambdaLayerArn(region: string, version: number, runtime: string, isArm: boolean, accountId?: string): string;
export declare function getExtensionLayerArn(region: string, version: number, isArm: boolean, accountId?: string): string;
export declare function generateLambdaLayerId(lambdaFunctionArn: string, runtime: string): string;
export declare function generateExtensionLayerId(lambdaFunctionArn: string): string;
export declare function generateLayerId(isExtensionLayer: boolean, functionArn: string, runtime: string): string;
