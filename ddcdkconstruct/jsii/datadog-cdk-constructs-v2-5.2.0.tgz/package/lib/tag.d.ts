import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { DatadogLambdaProps, DatadogStepFunctionsProps } from "./index";
import { LambdaFunction } from "./interfaces";
export declare function setTags(resource: LambdaFunction | sfn.StateMachine, props: DatadogLambdaProps | DatadogStepFunctionsProps): void;
