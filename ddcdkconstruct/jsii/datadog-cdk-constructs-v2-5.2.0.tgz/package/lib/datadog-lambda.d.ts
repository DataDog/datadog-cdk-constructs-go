import * as logs from "aws-cdk-lib/aws-logs";
import { Construct } from "constructs";
import { DatadogLambdaStrictProps, DatadogLambdaProps, Transport } from "./index";
import { LambdaFunction } from "./interfaces";
export declare class DatadogLambda extends Construct {
    scope: Construct;
    props: DatadogLambdaProps;
    transport: Transport;
    gitCommitShaOverride: string | undefined;
    gitRepoUrlOverride: string | undefined;
    lambdas: LambdaFunction[];
    contextGitShaOverrideKey: string;
    constructor(scope: Construct, id: string, props: DatadogLambdaProps);
    addLambdaFunctions(lambdaFunctions: LambdaFunction[], construct?: Construct): void;
    /**
     * Pre-set a Datadog environment variable on `lambdaFunction`. Call before
     * `addLambdaFunctions([lambdaFunction])`.
     *
     * Precedence, highest first:
     *   1. `func.addEnvironment()` called after `addLambdaFunctions()`.
     *   2. `DatadogLambdaProps` fields dedicated to `key` (for example, `env` for `DD_ENV`).
     *   3. This method.
     *   4. Construct defaults (for example, `enableDatadogTracing` for `DD_TRACE_ENABLED`).
     *
     * `addLambdaFunctions` merges `DD_TAGS` from `DatadogLambdaProps.tags`, per-function
     * tags from this method, and git tags from source code integration, in that order.
     * On duplicate tag keys, the later source wins.
     */
    setEnvironment(lambdaFunction: LambdaFunction, key: string, value: string): void;
    overrideGitMetadata(gitCommitSha: string, gitRepoUrl?: string): void;
    addGitCommitMetadata(lambdaFunctions: LambdaFunction[], gitCommitSha?: string, gitRepoUrl?: string): void;
    addForwarderToNonLambdaLogGroups(logGroups: logs.ILogGroup[]): void;
}
export declare function addCdkConstructVersionTag(lambdaFunction: LambdaFunction): void;
export declare function validateProps(props: DatadogLambdaProps, apiKeyArnOverride?: boolean): void;
export declare function checkForMultipleApiKeys(props: DatadogLambdaProps, apiKeyArnOverride?: boolean): void;
export declare function handleSettingPropDefaults(props: DatadogLambdaProps): DatadogLambdaStrictProps;
