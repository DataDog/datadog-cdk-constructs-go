export declare const layerRuntimeCatalog: readonly [{
    readonly runtime: "dotnet6";
    readonly runtimeType: "DOTNET";
    readonly layerNames: {
        readonly x86_64: "dd-trace-dotnet";
        readonly arm64: "dd-trace-dotnet-ARM";
    };
}, {
    readonly runtime: "dotnet8";
    readonly runtimeType: "DOTNET";
    readonly layerNames: {
        readonly x86_64: "dd-trace-dotnet";
        readonly arm64: "dd-trace-dotnet-ARM";
    };
}, {
    readonly runtime: "dotnet10";
    readonly runtimeType: "DOTNET";
    readonly layerNames: {
        readonly x86_64: "dd-trace-dotnet";
        readonly arm64: "dd-trace-dotnet-ARM";
    };
}, {
    readonly runtime: "nodejs14.x";
    readonly runtimeType: "NODE";
    readonly layerNames: {
        readonly x86_64: "Datadog-Node14-x";
        readonly arm64: "Datadog-Node14-x-ARM";
    };
}, {
    readonly runtime: "nodejs16.x";
    readonly runtimeType: "NODE";
    readonly layerNames: {
        readonly x86_64: "Datadog-Node16-x";
        readonly arm64: "Datadog-Node16-x-ARM";
    };
}, {
    readonly runtime: "nodejs18.x";
    readonly runtimeType: "NODE";
    readonly layerNames: {
        readonly x86_64: "Datadog-Node18-x";
        readonly arm64: "Datadog-Node18-x";
    };
}, {
    readonly runtime: "nodejs20.x";
    readonly runtimeType: "NODE";
    readonly layerNames: {
        readonly x86_64: "Datadog-Node20-x";
        readonly arm64: "Datadog-Node20-x";
    };
}, {
    readonly runtime: "nodejs22.x";
    readonly runtimeType: "NODE";
    readonly layerNames: {
        readonly x86_64: "Datadog-Node22-x";
        readonly arm64: "Datadog-Node22-x";
    };
}, {
    readonly runtime: "nodejs24.x";
    readonly runtimeType: "NODE";
    readonly layerNames: {
        readonly x86_64: "Datadog-Node24-x";
        readonly arm64: "Datadog-Node24-x";
    };
}, {
    readonly runtime: "nodejs26.x";
    readonly runtimeType: "NODE";
    readonly layerNames: {
        readonly x86_64: "Datadog-Node26-x";
        readonly arm64: "Datadog-Node26-x";
    };
}, {
    readonly runtime: "python3.7";
    readonly runtimeType: "PYTHON";
    readonly layerNames: {
        readonly x86_64: "Datadog-Python37";
        readonly arm64: "Datadog-Python37-ARM";
    };
}, {
    readonly runtime: "python3.8";
    readonly runtimeType: "PYTHON";
    readonly layerNames: {
        readonly x86_64: "Datadog-Python38";
        readonly arm64: "Datadog-Python38-ARM";
    };
}, {
    readonly runtime: "python3.9";
    readonly runtimeType: "PYTHON";
    readonly layerNames: {
        readonly x86_64: "Datadog-Python39";
        readonly arm64: "Datadog-Python39-ARM";
    };
}, {
    readonly runtime: "python3.10";
    readonly runtimeType: "PYTHON";
    readonly layerNames: {
        readonly x86_64: "Datadog-Python310";
        readonly arm64: "Datadog-Python310-ARM";
    };
}, {
    readonly runtime: "python3.11";
    readonly runtimeType: "PYTHON";
    readonly layerNames: {
        readonly x86_64: "Datadog-Python311";
        readonly arm64: "Datadog-Python311-ARM";
    };
}, {
    readonly runtime: "python3.12";
    readonly runtimeType: "PYTHON";
    readonly layerNames: {
        readonly x86_64: "Datadog-Python312";
        readonly arm64: "Datadog-Python312-ARM";
    };
}, {
    readonly runtime: "python3.13";
    readonly runtimeType: "PYTHON";
    readonly layerNames: {
        readonly x86_64: "Datadog-Python313";
        readonly arm64: "Datadog-Python313-ARM";
    };
}, {
    readonly runtime: "python3.14";
    readonly runtimeType: "PYTHON";
    readonly layerNames: {
        readonly x86_64: "Datadog-Python314";
        readonly arm64: "Datadog-Python314-ARM";
    };
}, {
    readonly runtime: "java8.al2";
    readonly runtimeType: "JAVA";
    readonly layerNames: {
        readonly x86_64: "dd-trace-java";
        readonly arm64: "dd-trace-java";
    };
}, {
    readonly runtime: "java11";
    readonly runtimeType: "JAVA";
    readonly layerNames: {
        readonly x86_64: "dd-trace-java";
        readonly arm64: "dd-trace-java";
    };
}, {
    readonly runtime: "java17";
    readonly runtimeType: "JAVA";
    readonly layerNames: {
        readonly x86_64: "dd-trace-java";
        readonly arm64: "dd-trace-java";
    };
}, {
    readonly runtime: "java21";
    readonly runtimeType: "JAVA";
    readonly layerNames: {
        readonly x86_64: "dd-trace-java";
        readonly arm64: "dd-trace-java";
    };
}, {
    readonly runtime: "java25";
    readonly runtimeType: "JAVA";
    readonly layerNames: {
        readonly x86_64: "dd-trace-java";
        readonly arm64: "dd-trace-java";
    };
}, {
    readonly runtime: "provided";
    readonly runtimeType: "CUSTOM";
}, {
    readonly runtime: "provided.al2";
    readonly runtimeType: "CUSTOM";
}, {
    readonly runtime: "provided.al2023";
    readonly runtimeType: "CUSTOM";
}, {
    readonly runtime: "ruby3.2";
    readonly runtimeType: "RUBY";
}, {
    readonly runtime: "ruby3.3";
    readonly runtimeType: "RUBY";
}, {
    readonly runtime: "ruby3.4";
    readonly runtimeType: "RUBY";
}, {
    readonly runtime: "ruby4.0";
    readonly runtimeType: "RUBY";
}, {
    readonly runtime: "ruby32";
    readonly layerNames: {
        readonly x86_64: "Datadog-Ruby3-2";
        readonly arm64: "Datadog-Ruby3-2-ARM";
    };
}, {
    readonly runtime: "ruby33";
    readonly layerNames: {
        readonly x86_64: "Datadog-Ruby3-3";
        readonly arm64: "Datadog-Ruby3-3-ARM";
    };
}, {
    readonly runtime: "ruby34";
    readonly layerNames: {
        readonly x86_64: "Datadog-Ruby3-4";
        readonly arm64: "Datadog-Ruby3-4-ARM";
    };
}, {
    readonly runtime: "ruby40";
    readonly layerNames: {
        readonly x86_64: "Datadog-Ruby4-0";
        readonly arm64: "Datadog-Ruby4-0-ARM";
    };
}];
