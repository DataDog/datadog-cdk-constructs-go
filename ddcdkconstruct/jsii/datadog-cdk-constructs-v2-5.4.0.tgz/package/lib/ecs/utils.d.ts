import * as ecs from "aws-cdk-lib/aws-ecs";
import { Construct } from "constructs";
import { DatadogECSBaseProps } from "./interfaces";
/**
 * Verifies that the provided props are valid for the Datadog ECS construct.
 */
export declare function validateECSBaseProps(props: DatadogECSBaseProps): void;
export declare function isOperatingSystemLinux(props: ecs.FargateTaskDefinitionProps | undefined): boolean;
export declare function isCpuArchitectureArm64(props: ecs.FargateTaskDefinitionProps | undefined): boolean;
export declare function configureEcsPolicies(task: ecs.TaskDefinition): void;
export declare function getSecretApiKey(scope: Construct, props: DatadogECSBaseProps): ecs.Secret | undefined;
export declare function addCdkConstructVersionTag(task: ecs.TaskDefinition): void;
/**
 * Converts comma-separated global tags to the whitespace-separated format that the Agent reads from DD_TAGS.
 * A JSON array of tags is passed through unchanged. For a token, CloudFormation does the conversion at deploy time.
 */
export declare function toAgentTags(globalTags: string): string;
/**
 * Warns about global tags and DD_TAGS values that the construct can't format correctly for the Agent.
 */
export declare function addGlobalTagsWarnings(scope: Construct, props: DatadogECSBaseProps): void;
