import { DatadogECSBaseProps } from "./interfaces";
/**
 * Default props for the Datadog ECS Fargate construct
 */
export declare const DatadogEcsBaseDefaultProps: DatadogECSBaseProps;
/**
 * IDs of the global tags warnings
 */
export declare const GlobalTagsWhitespaceWarningId = "datadog-cdk-constructs-v2:globalTagsWhitespace";
export declare const AgentTagsCommaWarningId = "datadog-cdk-constructs-v2:agentTagsComma";
