export declare class DatadogDefaultLayerVersions {
    static readonly NODE = 143;
    static readonly PYTHON = 130;
    static readonly JAVA = 29;
    static readonly DOTNET = 27;
    static readonly RUBY = 31;
    static readonly EXTENSION = 102;
}
