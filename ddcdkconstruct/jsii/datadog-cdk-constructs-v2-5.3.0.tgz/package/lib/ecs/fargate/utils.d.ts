import * as ecs from "aws-cdk-lib/aws-ecs";
import { DatadogECSFargateProps } from "./interfaces";
import { DatadogECSFargateInternalProps } from "./internal.interfaces";
export declare function mergeFargateProps(lowerPrecedence: DatadogECSFargateProps, higherPrecedence: DatadogECSFargateProps | undefined): DatadogECSFargateProps;
export declare function validateECSFargateProps(props: DatadogECSFargateInternalProps): void;
/**
 * Copies the container's awslogs configuration, or returns undefined when it uses another log driver.
 */
export declare function copyAwsLogsDriver(container: ecs.ContainerDefinition): ecs.LogDriver | undefined;
