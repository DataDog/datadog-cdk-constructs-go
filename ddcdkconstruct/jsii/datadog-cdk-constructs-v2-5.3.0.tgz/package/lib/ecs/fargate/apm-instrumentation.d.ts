import * as ecs from "aws-cdk-lib/aws-ecs";
import { APMInstrumentationConfig } from "./interfaces";
type EnvSeparator = " " | ":" | ",";
/**
 * A value added to a variable the container may already set. `separator` bounds each entry, so only
 * an exact entry counts as the tracer's. `preserveLeadingEmpty` keeps the default entry of path
 * lists such as `PHP_INI_SCAN_DIR`. `maxLength` limits the merged value in bytes.
 */
interface PositionedEnvFragment {
    readonly name: string;
    readonly value: string;
    readonly mode: "append" | "prepend";
    readonly separator: EnvSeparator;
    readonly preserveLeadingEmpty?: boolean;
    readonly maxLength?: number;
}
/**
 * A value set only when the container leaves the variable unset or empty.
 */
interface ScalarEnvFragment {
    readonly name: string;
    readonly value: string;
    readonly mode: "set-if-absent";
}
export type EnvFragment = PositionedEnvFragment | ScalarEnvFragment;
/**
 * The tracer image for the configured language and version.
 */
export declare function getTracerImage(config: APMInstrumentationConfig): string;
/**
 * The environment fragments that load the tracer in an application container.
 */
export declare function getLanguageFragments(config: APMInstrumentationConfig): EnvFragment[];
/**
 * The environment fragments added to the application container: the tracer's, and the tag
 * recording the injection mode.
 */
export declare function getInjectionFragments(config: APMInstrumentationConfig): EnvFragment[];
/**
 * Whether the tags record the injection mode.
 */
export declare function hasInjectionModeTag(tags: string | undefined): boolean;
/**
 * The container's environment with every fragment merged into the values it already sets.
 */
export declare function mergeInjectionEnvironment(containerName: string, props: ecs.ContainerDefinitionOptions, fragments: EnvFragment[]): Record<string, string>;
/**
 * Places one copy of the fragment in the current value, keeping every other entry.
 */
export declare function mergeEnvFragment(containerName: string, current: string | undefined, fragment: EnvFragment): string;
/**
 * Whether the value carries the fragment as an exact entry.
 */
export declare function hasEnvFragment(value: string | undefined, fragment: EnvFragment): boolean;
export {};
