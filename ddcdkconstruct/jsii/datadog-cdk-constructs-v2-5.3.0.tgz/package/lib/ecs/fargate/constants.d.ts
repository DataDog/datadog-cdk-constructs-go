import { FirelensConfigFileType } from "aws-cdk-lib/aws-ecs";
import { DatadogECSFargateProps } from "./interfaces";
/**
 * Default environment variables for the Agent in Fargate Tasks
 */
export declare const FargateDefaultEnvVars: {
    ECS_FARGATE: string;
};
/**
 * Default service name for the Datadog Agent
 */
export declare const DatadogAgentServiceName = "datadog-agent";
/**
 * Default props for the Datadog ECS Fargate construct
 */
export declare const DatadogEcsFargateDefaultProps: DatadogECSFargateProps;
/**
 * Default CWS entrypoint prefix for application containers
 */
export declare const EntryPointPrefixCWS: string[];
/**
 * Config file type for the Firelens configuration parsing JSON
 */
export declare const ParseJsonFirelensConfigFileType = FirelensConfigFileType.FILE;
/**
 * Config file path for the Firelens configuration parsing JSON
 */
export declare const ParseJsonFirelensConfigFileValue = "/fluent-bit/configs/parse-json.conf";
/**
 * Container names of the Datadog log router, CWS, and Agent config init containers
 */
export declare const LogRouterContainerName = "datadog-log-router";
export declare const CWSContainerName = "cws-instrumentation-init";
export declare const InitVolumeContainerName = "init-volume";
/**
 * Container and volume that copy the tracer for automatic APM instrumentation
 */
export declare const TracerContainerName = "datadog-tracer";
export declare const TracerVolumeName = "datadog-tracer";
/**
 * Path where the tracer volume is mounted in the tracer and application containers
 */
export declare const TracerMountPath = "/datadog-lib";
/**
 * Registry and default tag of the Datadog tracer images
 */
export declare const TracerImageRegistry = "public.ecr.aws/datadog";
export declare const DefaultTracerVersion = "latest";
/**
 * Valid tracer image tag
 */
export declare const TracerImageTagRegExp: RegExp;
/**
 * Entrypoint every tracer image exposes, which copies the tracer into the path it is given
 */
export declare const TracerCopyEntryPoint = "/datadog-init/copy-lib.sh";
/**
 * Root, so the tracer copy can write into the root-owned task volume
 */
export declare const TracerUser = "0";
/**
 * Log driver the tracer container reuses from the container that loads the tracer
 */
export declare const AwsLogsLogDriver = "awslogs";
/**
 * Task definition tag recording the automatic APM instrumentation mode
 */
export declare const InjectionModeTagKey = "dd_sls_injection_mode";
export declare const SingleLanguageInjectionMode = "single_language";
/**
 * DD_TAGS entry recording the automatic APM instrumentation mode on the instrumented container
 */
export declare const SingleLanguageInjectionModeTag = "_dd.injection.mode:serverless-single-lang";
/**
 * IDs of the automatic APM instrumentation warnings
 */
export declare const InjectionModeTagWarningId = "datadog-cdk-constructs-v2:apmInstrumentationTagRemoved";
export declare const TracerLogsWarningId = "datadog-cdk-constructs-v2:apmInstrumentationTracerLogsNotCollected";
/**
 * Containers the construct manages, which never load the tracer
 */
export declare const DatadogManagedContainerNames: ReadonlySet<string>;
