import * as ecs from "aws-cdk-lib/aws-ecs";
import { Construct } from "constructs";
import { DatadogECSFargateProps } from "./interfaces";
/**
 * The Datadog ECS Fargate construct manages the Datadog
 * configuration for ECS Fargate tasks.
 */
export declare class DatadogECSFargate {
    private readonly datadogProps;
    constructor(datadogProps: DatadogECSFargateProps);
    /**
     * Creates a new Fargate Task Definition instrumented with Datadog.
     * Merges the provided task's datadogProps with the class's datadogProps.
     * @param scope
     * @param id
     * @param props optional: Fargate Task Definition properties
     * @param datadogProps optional: Datadog ECS Fargate properties override values
     */
    fargateTaskDefinition(scope: Construct, id: string, props?: ecs.FargateTaskDefinitionProps, datadogProps?: DatadogECSFargateProps): DatadogECSFargateTaskDefinition;
}
/**
 * The Datadog ECS Fargate Task Definition automatically instruments the
 * ECS Fargate task and containers with configured Datadog features.
 */
export declare class DatadogECSFargateTaskDefinition extends ecs.FargateTaskDefinition {
    private readonly scope;
    private readonly datadogProps;
    readonly datadogContainer: ecs.ContainerDefinition;
    readonly logContainer?: ecs.ContainerDefinition;
    readonly cwsContainer?: ecs.ContainerDefinition;
    private _tracerContainer?;
    private readonly applicationContainerNames;
    private tracerTarget?;
    constructor(scope: Construct, id: string, props?: ecs.FargateTaskDefinitionProps, datadogProps?: DatadogECSFargateProps);
    /**
     * The container that copies the tracer, added with the container that loads the tracer.
     */
    get tracerContainer(): ecs.ContainerDefinition | undefined;
    /**
     * Adds a new container to the task definition.
     *
     * Modifies properties of container to support specified agent configuration in task.
     */
    addContainer(id: string, containerProps: ecs.ContainerDefinitionOptions): ecs.ContainerDefinition;
    /**
     * Whether the added container loads the tracer. Without `containerName`, the only application
     * container is selected, so a second one is rejected rather than chosen by the order they were added.
     */
    private selectTracerTarget;
    /**
     * Modifies the container props to support specified Datadog agent configuration.
     */
    private configureContainerProps;
    /**
     * Configures the container to support Datadog agent configuration.
     */
    private configureContainer;
    private thisCreateInitContainer;
    private createAgentContainer;
    private createLogContainer;
    private createLogDriver;
    private createCWSContainer;
    /**
     * Adds the container that copies the tracer for the target. Its logs go through the log router when
     * log collection is enabled, and otherwise where the target's awslogs driver sends them.
     */
    private createTracerContainer;
    /**
     * Checks the tracer target against every container in the task definition,
     * and reports tracer settings on it that changed after it was added.
     * Warns when its DD_TAGS no longer records the injection mode.
     */
    private validateAPMInstrumentation;
    private getCompleteProps;
}
