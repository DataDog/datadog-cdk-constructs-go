import { DatadogECSManagedInstancesProps } from "./interfaces";
/**
 * Default environment variables for the Agent in a daemon task on ECS Managed Instances.
 */
export declare const ManagedInstancesDefaultEnvVars: {
    ECS_MANAGED_INSTANCES: string;
};
/**
 * Default service name for the Datadog Agent
 */
export declare const DatadogAgentServiceName = "datadog-agent";
/**
 * Minimum Datadog Agent version required for ECS Managed Instances daemon mode.
 */
export declare const MinimumAgentVersion = "7.77.0";
/**
 * The path where the host containerd socket is mounted inside the Datadog
 * Agent container, regardless of the host path configured via `criSocketPath`.
 */
export declare const ContainerCriSocketPath = "/var/run/containerd/containerd.sock";
/**
 * Names of the volumes the construct manages. User-provided volumes cannot reuse these.
 */
export declare const ManagedVolumeNames: string[];
/**
 * Paths inside the Datadog Agent container where the construct mounts its own volumes.
 * User-provided volumes cannot mount at these paths.
 */
export declare const ManagedContainerPaths: string[];
/**
 * The static daemon bridge IP used to reach the Datadog Agent daemon over TCP
 * (IPv4). Daemons on an ECS Managed Instance share a single network namespace.
 */
export declare const DaemonBridgeIpv4 = "169.254.172.2";
/**
 * The port the Datadog Agent listens on for APM traces over TCP.
 */
export declare const ApmTcpPort = 8126;
/**
 * Default props for the Datadog ECS Managed Instances construct.
 */
export declare const DatadogEcsManagedInstancesDefaultProps: Partial<DatadogECSManagedInstancesProps>;
