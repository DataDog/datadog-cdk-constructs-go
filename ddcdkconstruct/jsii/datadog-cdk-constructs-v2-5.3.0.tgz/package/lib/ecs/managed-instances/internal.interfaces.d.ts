import { Secret } from "aws-cdk-lib/aws-ecs";
import { EnvVarManager } from "../environment";
import { DatadogECSManagedInstancesProps } from "./interfaces";
/**
 * Internal props for the Datadog ECS Managed Instances construct.
 */
export interface DatadogECSManagedInstancesInternalProps extends DatadogECSManagedInstancesProps {
    readonly envVarManager: EnvVarManager;
    readonly isSocketRequired: boolean;
    readonly isProtocolRequired: boolean;
    readonly datadogSecret?: Secret;
}
