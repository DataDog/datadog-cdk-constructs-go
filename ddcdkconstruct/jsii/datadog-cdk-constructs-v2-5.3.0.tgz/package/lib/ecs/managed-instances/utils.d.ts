import { DatadogECSManagedInstancesProps } from "./interfaces";
import { DatadogECSManagedInstancesInternalProps } from "./internal.interfaces";
export declare function mergeManagedInstancesProps(lowerPrecedence: DatadogECSManagedInstancesProps, higherPrecedence: DatadogECSManagedInstancesProps | undefined): DatadogECSManagedInstancesProps;
export declare function validateECSManagedInstancesProps(props: DatadogECSManagedInstancesInternalProps): void;
