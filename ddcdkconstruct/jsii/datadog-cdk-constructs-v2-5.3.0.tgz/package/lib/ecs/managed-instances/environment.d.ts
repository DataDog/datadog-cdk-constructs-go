import { DatadogECSManagedInstancesProps } from "./interfaces";
import { EnvVarManager } from "../environment";
export declare class ManagedInstancesEnvVarManager extends EnvVarManager {
    constructor(props: DatadogECSManagedInstancesProps, isSocketRequired: boolean, isProtocolRequired: boolean);
}
