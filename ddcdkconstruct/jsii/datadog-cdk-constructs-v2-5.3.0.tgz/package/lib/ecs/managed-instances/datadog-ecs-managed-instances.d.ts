import * as ecs from "aws-cdk-lib/aws-ecs";
import * as iam from "aws-cdk-lib/aws-iam";
import { Construct } from "constructs";
import { DatadogECSManagedInstancesProps } from "./interfaces";
type VolumeProperty = ecs.CfnDaemonTaskDefinition.VolumeProperty;
type MountPointProperty = ecs.CfnDaemonTaskDefinition.MountPointProperty;
/**
 * The Datadog ECS Managed Instances construct manages the Datadog
 * configuration for Datadog Agent daemons running on ECS Managed Instances.
 */
export declare class DatadogECSManagedInstances {
    private readonly datadogProps;
    constructor(datadogProps: DatadogECSManagedInstancesProps);
    /**
     * Creates a new Datadog Agent daemon task definition (and, unless
     * `createDaemon` is false, the daemon itself).
     * Merges the provided datadogProps with the class's datadogProps.
     * @param scope
     * @param id
     * @param datadogProps optional: Datadog ECS Managed Instances properties override values
     */
    daemonTaskDefinition(scope: Construct, id: string, datadogProps?: DatadogECSManagedInstancesProps): DatadogECSManagedInstancesDaemonTaskDefinition;
}
/**
 * Deploys the Datadog Agent as an ECS Managed Daemon on ECS Managed Instances.
 *
 * Unlike `DatadogECSFargateTaskDefinition`, this construct does not extend an
 * AWS CDK L2 task definition class - `AWS::ECS::DaemonTaskDefinition` has no
 * L2 equivalent, and its container definition is a single value set at
 * construction rather than built incrementally via `addContainer`. This is
 * inherent to the daemon deployment model, not a limitation relative to the
 * Fargate module: the daemon task definition holds only the Datadog Agent
 * container. Application containers run in their own, separate task
 * definitions and are wired to the daemon over the shared UDS socket volume
 * (see `appDdSocketsVolume` / `appDdSocketsMountPoint`) or TCP (see
 * `dogstatsdEnvironment` / `apmEnvironment`).
 */
export declare class DatadogECSManagedInstancesDaemonTaskDefinition extends Construct {
    private readonly datadogProps;
    /**
     * The underlying `AWS::ECS::DaemonTaskDefinition` resource.
     */
    readonly taskDefinition: ecs.CfnDaemonTaskDefinition;
    /**
     * The underlying `AWS::ECS::Daemon` resource. Only defined if `createDaemon` is true.
     */
    readonly daemon?: ecs.CfnDaemon;
    /**
     * The IAM role used by the Datadog Agent container to make AWS API calls.
     */
    readonly taskRole: iam.IRole;
    /**
     * The IAM role used by ECS to pull the Datadog Agent image and access secrets.
     */
    readonly executionRole: iam.IRole;
    /**
     * Volume definition for the shared UDS socket directory. Add this to an
     * application task definition's volumes to enable UDS communication with
     * the Datadog Agent daemon. Only defined when UDS is required.
     */
    readonly appDdSocketsVolume?: VolumeProperty;
    /**
     * Mount point for the shared UDS socket directory. Add this to an
     * application container's mountPoints. Only defined when UDS is required.
     */
    readonly appDdSocketsMountPoint?: MountPointProperty;
    /**
     * Environment variables for DogStatsD in application containers. Empty
     * unless DogStatsD is enabled. Points the application at the Agent socket
     * when UDS is in use, or at the daemon bridge address when it is not.
     */
    readonly dogstatsdEnvironment: ecs.CfnDaemonTaskDefinition.KeyValuePairProperty[];
    /**
     * Environment variables for APM in application containers. Includes the
     * trace agent URL (the Agent socket when UDS is in use, otherwise the daemon
     * bridge address), `DD_PROFILING_ENABLED` when
     * `apm.isProfilingEnabled` is set, and `DD_TRACE_INFERRED_PROXY_SERVICES_ENABLED`
     * when `apm.traceInferredProxyServices` is set. Empty unless APM is enabled.
     */
    readonly apmEnvironment: ecs.CfnDaemonTaskDefinition.KeyValuePairProperty[];
    /**
     * Environment variables for Data Streams Monitoring in application
     * containers. Empty unless APM and `apm.dataStreams` are both enabled.
     * Data Streams Monitoring is an application/tracer-side feature - this is
     * for the application container that produces or consumes messages, not
     * the Datadog Agent container.
     */
    readonly dataStreamsEnvironment: ecs.CfnDaemonTaskDefinition.KeyValuePairProperty[];
    constructor(scope: Construct, id: string, datadogProps?: DatadogECSManagedInstancesProps);
    /**
     * Volumes the module manages (containerd/proc/cgroup, the shared UDS socket
     * directory, and the network-monitoring debug mount), each paired with the
     * mount point the agent container itself uses to read/write it.
     */
    private buildVolumeMounts;
    private buildAgentContainerDefinition;
    private resolveExecutionRole;
    private resolveTaskRole;
    private renderTags;
    private addCdkConstructVersionTag;
    private getCompleteProps;
}
export {};
