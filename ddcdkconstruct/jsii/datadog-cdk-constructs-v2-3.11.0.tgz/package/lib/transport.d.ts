import * as lambda from "aws-cdk-lib/aws-lambda";
export declare const API_KEY_ENV_VAR = "DD_API_KEY";
export declare const API_KEY_SECRET_ARN_ENV_VAR = "DD_API_KEY_SECRET_ARN";
export declare const API_KEY_SSM_ARN_ENV_VAR = "DD_API_KEY_SSM_ARN";
export declare const KMS_API_KEY_ENV_VAR = "DD_KMS_API_KEY";
export declare const SITE_URL_ENV_VAR = "DD_SITE";
export declare const FLUSH_METRICS_TO_LOGS_ENV_VAR = "DD_FLUSH_TO_LOG";
export declare const transportDefaults: {
    site: string;
    flushMetricsToLogs: boolean;
    enableDatadogTracing: boolean;
};
export declare class Transport {
    flushMetricsToLogs: boolean;
    site: string;
    apiKey?: string;
    apiKeySecretArn?: string;
    apiKeySsmArn?: string;
    apiKmsKey?: string;
    extensionLayerVersion?: number;
    extensionLayerArn?: string;
    constructor(flushMetricsToLogs?: boolean, site?: string, apiKey?: string, apiKeySecretArn?: string, apiKeySsmArn?: string, apiKmsKey?: string, extensionLayerVersion?: number, extensionLayerArn?: string);
    applyEnvVars(lam: lambda.Function): void;
}
