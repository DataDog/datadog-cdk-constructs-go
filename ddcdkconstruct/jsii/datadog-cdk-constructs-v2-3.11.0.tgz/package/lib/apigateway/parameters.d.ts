import * as apigatewayv2 from "aws-cdk-lib/aws-apigatewayv2";
declare const DatadogAPIGatewayRequestParameters: {
    "integration.request.header.x-dd-proxy": string;
    "integration.request.header.x-dd-proxy-request-time-ms": string;
    "integration.request.header.x-dd-proxy-domain-name": string;
    "integration.request.header.x-dd-proxy-httpmethod": string;
    "integration.request.header.x-dd-proxy-path": string;
    "integration.request.header.x-dd-proxy-stage": string;
};
declare function appendDatadogHeaders(existingMapping?: apigatewayv2.ParameterMapping): apigatewayv2.ParameterMapping;
declare const DatadogAPIGatewayV2ParameterMapping: apigatewayv2.ParameterMapping;
export { DatadogAPIGatewayRequestParameters, DatadogAPIGatewayV2ParameterMapping, appendDatadogHeaders };
