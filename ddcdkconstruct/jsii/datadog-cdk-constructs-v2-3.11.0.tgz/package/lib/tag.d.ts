import * as lambda from "aws-cdk-lib/aws-lambda";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { DatadogLambdaProps, DatadogStepFunctionsProps } from "./index";
export declare function setTags(resource: lambda.Function | sfn.StateMachine, props: DatadogLambdaProps | DatadogStepFunctionsProps): void;
