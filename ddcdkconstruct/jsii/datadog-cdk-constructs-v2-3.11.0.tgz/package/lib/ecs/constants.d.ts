import { DatadogECSBaseProps } from "./interfaces";
/**
 * Default props for the Datadog ECS Fargate construct
 */
export declare const DatadogEcsBaseDefaultProps: DatadogECSBaseProps;
