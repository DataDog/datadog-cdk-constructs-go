import { DatadogECSFargateProps } from "./interfaces";
import { DatadogECSFargateInternalProps } from "./internal.interfaces";
export declare function mergeFargateProps(lowerPrecedence: DatadogECSFargateProps, higherPrecedence: DatadogECSFargateProps | undefined): DatadogECSFargateProps;
export declare function validateECSFargateProps(props: DatadogECSFargateInternalProps): void;
