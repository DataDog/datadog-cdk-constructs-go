import { FirelensConfigFileType } from "aws-cdk-lib/aws-ecs";
import { DatadogECSFargateProps } from "./interfaces";
/**
 * Default environment variables for the Agent in Fargate Tasks
 */
export declare const FargateDefaultEnvVars: {
    ECS_FARGATE: string;
};
/**
 * Default service name for the Datadog Agent
 */
export declare const DatadogAgentServiceName = "datadog-agent";
/**
 * Default props for the Datadog ECS Fargate construct
 */
export declare const DatadogEcsFargateDefaultProps: DatadogECSFargateProps;
/**
 * Default CWS entrypoint prefix for application containers
 */
export declare const EntryPointPrefixCWS: string[];
/**
 * Config file type for the Firelens configuration parsing JSON
 */
export declare const ParseJsonFirelensConfigFileType = FirelensConfigFileType.FILE;
/**
 * Config file path for the Firelens configuration parsing JSON
 */
export declare const ParseJsonFirelensConfigFileValue = "/fluent-bit/configs/parse-json.conf";
