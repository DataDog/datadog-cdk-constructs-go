import { HealthCheck, FirelensOptions, FireLensLogDriver } from "aws-cdk-lib/aws-ecs";
import { CWSFeatureConfig, DatadogECSBaseProps, LogCollectionFeatureConfig } from "../interfaces";
export interface DatadogECSFargateProps extends DatadogECSBaseProps {
    readonly logCollection?: FargateLogCollectionFeatureConfig;
    readonly cws?: FargateCWSFeatureConfig;
}
export interface FargateCWSFeatureConfig extends CWSFeatureConfig {
    /**
     * The minimum number of CPU units to reserve
     * for the Datadog CWS init container.
     */
    readonly cpu?: number;
    /**
     * The amount (in MiB) of memory to present
     * to the Datadog CWS init container.
     */
    readonly memoryLimitMiB?: number;
}
export interface FargateLogCollectionFeatureConfig extends LogCollectionFeatureConfig {
    /**
     * Type of log collection.
     */
    readonly loggingType?: LoggingType;
    /**
     * Fluentbit log collection configuration.
     */
    readonly fluentbitConfig?: FluentbitConfig;
}
export interface FluentbitConfig {
    /**
     * Configuration for the Datadog log driver.
     */
    readonly logDriverConfig?: DatadogECSLogDriverProps;
    /**
     * Supply own FireLensLogDriver. Either this or logDriverConfig can be provided but not both.
     */
    readonly firelensLogDriver?: FireLensLogDriver;
    /**
     * Firelens options for the Fluentbit container.
     */
    readonly firelensOptions?: DatadogFirelensOptions;
    /**
     * Makes the log router essential.
     */
    readonly isLogRouterEssential?: boolean;
    /**
     * Enables the log router health check.
     */
    readonly isLogRouterDependencyEnabled?: boolean;
    /**
     * Health check configuration for the log router.
     */
    readonly logRouterHealthCheck?: HealthCheck;
    /**
     * The registry to pull the Fluentbit container image from.
     */
    readonly registry?: string;
    /**
     * The version of the Fluentbit container image to use.
     */
    readonly imageVersion?: string;
    /**
     * The minimum number of CPU units to reserve
     * for the Datadog fluent-bit container.
     */
    readonly cpu?: number;
    /**
     * The amount (in MiB) of memory to present
     * to the Datadog fluent-bit container.
     */
    readonly memoryLimitMiB?: number;
}
/**
 * Type of datadog logging configuration.
 */
export declare enum LoggingType {
    /**
     * Forwarding logs to Datadog using Fluentbit container.
     * Only compatible on Linux.
     */
    FLUENTBIT = "fluentbit"
}
/**
 * Datadog Fluentbit log driver configuration.
 * https://docs.fluentbit.io/manual/pipeline/outputs/datadog
 */
export interface DatadogECSLogDriverProps {
    readonly hostEndpoint?: string;
    readonly tls?: string;
    readonly compress?: string;
    readonly serviceName?: string;
    readonly sourceName?: string;
    readonly messageKey?: string;
}
export interface DatadogFirelensOptions extends FirelensOptions {
    /**
     * Overrides the config file type and value to support JSON parsing.
     */
    readonly isParseJson?: boolean;
}
