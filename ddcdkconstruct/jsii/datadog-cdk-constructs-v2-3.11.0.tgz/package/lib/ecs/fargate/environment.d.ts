import { DatadogECSFargateProps } from "./interfaces";
import { EnvVarManager } from "../environment";
export declare class FargateEnvVarManager extends EnvVarManager {
    constructor(props: DatadogECSFargateProps);
}
