import * as ecs from "aws-cdk-lib/aws-ecs";
import { Construct } from "constructs";
import { DatadogECSBaseProps } from "./interfaces";
/**
 * Verifies that the provided props are valid for the Datadog ECS construct.
 */
export declare function validateECSBaseProps(props: DatadogECSBaseProps): void;
export declare function isOperatingSystemLinux(props: ecs.FargateTaskDefinitionProps | undefined): boolean;
export declare function configureEcsPolicies(task: ecs.TaskDefinition): void;
export declare function getSecretApiKey(scope: Construct, props: DatadogECSBaseProps): ecs.Secret | undefined;
export declare function addCdkConstructVersionTag(task: ecs.TaskDefinition): void;
