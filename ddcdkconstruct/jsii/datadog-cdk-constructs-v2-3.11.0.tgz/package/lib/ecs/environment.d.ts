export declare class EnvVarManager {
    private envVars;
    private overwrittenKeys;
    constructor(defaultEnvVars?: Record<string, string>);
    /**
     * Adds an environment variable if the value is not undefined.
     * If the key already exists, it records that it has been overwritten.
     */
    add(key: string, value: string | undefined): void;
    /**
     * Adds all environment variables from a record.
     */
    addAll(envVars: Record<string, string> | undefined): void;
    /**
     * Retrieves an environment variable by key.
     */
    retrieve(key: string): string | undefined;
    /**
     * Returns all stored environment variables.
     */
    retrieveAll(): Record<string, string>;
    /**
     * Returns a list of keys that have been overwritten.
     */
    retrieveOverwrittenKeys(): string[];
    /**
     * Returns a string representation of the environment variables.
     */
    toString(): string;
}
