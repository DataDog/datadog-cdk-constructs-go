/**
 * Builds a payload for a Step Function LambdaInvoke task, so the Step Function traces
 * can be merged with downstream Lambda traces.
 *
 * This function modifies the provided payload to include context fields necessary
 * for trace merging purposes. If the payload already contains any of these fields,
 * an error is thrown to avoid conflicts.
 *
 * @param payload - The user's payload object. Defaults to an empty object.
 * @returns The modified payload object with necessary context added.
 * @throws {ConflictError} If the payload already contains `Execution`, `State`, or `StateMachine` fields.
 */
export declare function buildStepFunctionLambdaTaskPayloadToMergeTraces(payload?: {
    [key: string]: any;
}): {
    [key: string]: any;
};
/**
 * Builds an input for a Step Function execution task, so the Step Function traces
 * can be merged with downstream Step Function traces.
 *
 * This function modifies the provided input to include context fields necessary
 * for trace merging purposes. If the input already contains CONTEXT or CONTEXT.$ field,
 * an error is thrown to avoid conflicts.
 *
 * @param input - The user's input object. Defaults to an empty object.
 * @returns The modified input object with necessary context added.
 * @throws {ConflictError} If the input already contains `CONTEXT` or `CONTEXT.$` fields.
 */
export declare function buildStepFunctionSfnExecutionTaskInputToMergeTraces(input?: {
    [key: string]: any;
}): {
    [key: string]: any;
};
