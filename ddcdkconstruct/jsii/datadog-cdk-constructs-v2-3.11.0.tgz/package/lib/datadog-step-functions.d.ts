import { Stack } from "aws-cdk-lib";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { Construct } from "constructs";
import { DatadogStepFunctionsProps } from "./index";
export declare class DatadogStepFunctions extends Construct {
    static buildLambdaPayloadToMergeTraces(payload?: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
    static buildStepFunctionTaskInputToMergeTraces(input?: {
        [key: string]: any;
    }): {
        [key: string]: any;
    };
    scope: Construct;
    props: DatadogStepFunctionsProps;
    stack: Stack;
    constructor(scope: Construct, id: string, props: DatadogStepFunctionsProps);
    addStateMachines(stateMachines: sfn.StateMachine[], construct?: Construct): void;
    private addStateMachine;
    /**
     * Set up logging for the given state machine:
     * 1. Set log level to ALL
     * 2. Set includeExecutionData to true
     * 3. Set destination log group (if not set already)
     * 4. Add permissions to the state machine role to log to CloudWatch Logs
     *
     * Also extracts the log group if it exists.
     *
     * @returns the existing or newly created log group
     */
    private setUpLogging;
    private isLogDestinationPropertyArray;
}
/**
 * Builds log group name for a state machine using its CDK path.
 * The path is like "MyStack/MyStateMachine", which includes the stack name and the relative path of the state machine
 * in the stack. This guarantees no two state machines share the same log group name because:
 * 1. stack name is unique in a region in an AWS account
 * 2. relative path is unique in a stack
 * @returns log group name like "/aws/vendedlogs/states/MyCdkStack-MyStateMachine-Logs" (without env)
 *                           or "/aws/vendedlogs/states/MyCdkStack-MyStateMachine-Logs-dev" (with env)
 */
export declare const buildLogGroupName: (stateMachine: sfn.StateMachine, env: string | undefined) => string;
