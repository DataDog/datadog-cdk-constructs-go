import { App, Stack, StackProps } from "aws-cdk-lib";
export declare class ExampleStack extends Stack {
    constructor(scope: App, id: string, props?: StackProps);
}
