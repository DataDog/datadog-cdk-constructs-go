import * as lambda from "aws-cdk-lib/aws-lambda";
import * as logs from "aws-cdk-lib/aws-logs";
import { Construct } from "constructs";
import { DatadogLambdaStrictProps, DatadogLambdaProps, Transport } from "./index";
import { LambdaFunction } from "./interfaces";
export declare class DatadogLambda extends Construct {
    scope: Construct;
    props: DatadogLambdaProps;
    transport: Transport;
    gitCommitShaOverride: string | undefined;
    gitRepoUrlOverride: string | undefined;
    lambdas: LambdaFunction[];
    contextGitShaOverrideKey: string;
    constructor(scope: Construct, id: string, props: DatadogLambdaProps);
    addLambdaFunctions(lambdaFunctions: LambdaFunction[], construct?: Construct): void;
    overrideGitMetadata(gitCommitSha: string, gitRepoUrl?: string): void;
    addGitCommitMetadata(lambdaFunctions: LambdaFunction[], gitCommitSha?: string, gitRepoUrl?: string): void;
    addForwarderToNonLambdaLogGroups(logGroups: logs.ILogGroup[]): void;
}
export declare function addCdkConstructVersionTag(lambdaFunction: lambda.Function): void;
export declare function validateProps(props: DatadogLambdaProps, apiKeyArnOverride?: boolean): void;
export declare function checkForMultipleApiKeys(props: DatadogLambdaProps, apiKeyArnOverride?: boolean): void;
export declare function handleSettingPropDefaults(props: DatadogLambdaProps): DatadogLambdaStrictProps;
