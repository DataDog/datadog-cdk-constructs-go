import * as lambda from "aws-cdk-lib/aws-lambda";
import { ILogGroup } from "aws-cdk-lib/aws-logs";
import * as sfn from "aws-cdk-lib/aws-stepfunctions";
import { Construct } from "constructs";
export declare function addForwarder(scope: Construct, lam: lambda.Function, forwarderArn: string, createForwarderPermissions: boolean): void;
export declare function addForwarderForStateMachine(scope: Construct, stateMachine: sfn.StateMachine, forwarderArn: string, logGroup: ILogGroup): void;
export declare function addForwarderToLogGroups(scope: Construct, logGroups: ILogGroup[], forwarderArn: string, createForwarderPermissions: boolean): void;
export declare function generateForwarderConstructId(forwarderArn: string): string;
export declare function generateSubscriptionFilterName(functionUniqueId: string, forwarderArn: string): string;
