export declare class DatadogDefaultLayerVersions {
    static readonly NODE = 144;
    static readonly PYTHON = 130;
    static readonly JAVA = 31;
    static readonly DOTNET = 28;
    static readonly RUBY = 31;
    static readonly EXTENSION = 105;
}
