export declare class DatadogDefaultLayerVersions {
    static readonly NODE = 140;
    static readonly PYTHON = 125;
    static readonly JAVA = 27;
    static readonly DOTNET = 25;
    static readonly RUBY = 29;
    static readonly EXTENSION = 98;
}
