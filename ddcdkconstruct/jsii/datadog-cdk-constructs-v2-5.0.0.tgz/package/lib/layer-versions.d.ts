export declare class DatadogDefaultLayerVersions {
    static readonly NODE = 142;
    static readonly PYTHON = 127;
    static readonly JAVA = 27;
    static readonly DOTNET = 25;
    static readonly RUBY = 30;
    static readonly EXTENSION = 99;
}
